# Next Markdown Blog

Simple static blog using markdown and Next.js

[DEMO](https://next-markdown-blog-drab.vercel.app/)

## Usage

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for prod and export static website
npm run build
```
